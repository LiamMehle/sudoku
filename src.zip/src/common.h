#pragma once

#define term_height 256