#pragma once
void clear_screen();