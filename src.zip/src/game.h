#pragma once
#include "types.h"
void start_game(const Settings settings);